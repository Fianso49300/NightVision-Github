<?php

namespace ExodeCore\Commands;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\Listener;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use jojoe77777\FormAPI\SimpleForm;
use pocketmine\network\mcpe\protocol\ToastRequestPacket;
use pocketmine\form\FormValidationException;

class Vison extends PluginBase implements Listener{

  public function onEnable(): void
  {
      $this->getLogger()->notice("l§e»§r§e §fLa vision nocturne a bien été activer");
      @mkdir($this->getDataFolder());
  }
  public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
    $commandname = $command->getName();
    if($commandname = "nv"){
      if($sender instanceof Player){
        $form = new SimpleForm(function(Player $sender, int $data = null) {
          $result = $data;
          if($result === null) { return true; }
          switch($result){
            case 0:
              $effect = new EffectInstance(VanillaEffects::NIGHT_VISION(), 20 * 900000, 10, false);
              $sender->getEffects()->add($effect);
              $sender->getNetworkSession()->sendDataPacket(ToastRequestPacket::create(("Titleadd_Achivement"), (("nvadd_description"))));
              break;
            case 1: 
              $sender->getEffects()->remove(VanillaEffects::NIGHT_VISION());
              $sender->getNetworkSession()->sendDataPacket(ToastRequestPacket::create(("Titletremove_Achivement"), (("nvremove_description"))));
              break;
          }
        });
        $form->setTitle("§e§lVison Nocturne");
        $form->setContent("Activer/Desactiver la vision nocturne");
        $form->addButton("§2Ajouter");
        $form->addButton("§cRetirer");
        $form->sendToPlayer($sender);
      }
    }
    return true;
  }
}